package com.proudlegal.Activity

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.proudlegal.databinding.ActivityOtpBinding

class OtpActivity : AppCompatActivity() {
    lateinit var binding: ActivityOtpBinding
    private val PHONE_NUMBER = "+91-9779466813"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOtpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.veryfyBtn.setOnClickListener {
            val intent = Intent(this, ResetPasswordActivity::class.java)
            startActivity(intent)

        }
        binding.resendTxt.setOnClickListener {
            Toast.makeText(baseContext, "resend otp", Toast.LENGTH_SHORT).show()
        }
        binding.backForget.setOnClickListener {
            finish()
        }
        binding.givecall.setOnClickListener {
            val dialIntent = Intent(Intent.ACTION_DIAL)
            dialIntent.data = Uri.parse("tel:$PHONE_NUMBER")
            startActivity(dialIntent)
        }
    }
}