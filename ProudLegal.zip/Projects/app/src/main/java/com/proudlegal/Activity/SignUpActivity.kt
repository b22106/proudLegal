package com.proudlegal.Activity

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.proudlegal.databinding.ActivitySignUpBinding

class SignUpActivity : AppCompatActivity(), View.OnClickListener {
    lateinit var binding: ActivitySignUpBinding
    private val PHONE_NUMBER = "+91-9779466813"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)
        listiner()
    }

    private fun listiner() {
        binding.backSignup.setOnClickListener(this)
        binding.signinTxt.setOnClickListener(this)
        binding.signupBtn.setOnClickListener(this)
        binding.givecall.setOnClickListener(this)
    }

    override fun onClick(view: View?) {
        if (view === binding.backSignup) {
            finish()
        } else if (view === binding.signinTxt) {
            finish()
        }else if(view===binding.givecall){
            val dialIntent = Intent(Intent.ACTION_DIAL)
            dialIntent.data = Uri.parse("tel:$PHONE_NUMBER")
            startActivity(dialIntent)

        } else if (view === binding.signupBtn) {

            val fullname:String = binding.fullname.getText().toString().trim();
            val type:String = binding.type.getText().toString().trim();
            val status:String=binding.status.getText().toString().trim();
            val fulladdress:String =binding.fulladdress.getText().toString().trim();
            val contactNumber:String =binding.contactNumber.getText().toString().trim();
            val panNumber:String =binding.panNumber.getText().toString().trim();
            val gstNumber:String =binding.gstNumber.getText().toString().trim();
            val designation:String =binding.designation.getText().toString().trim();
            val email:String =binding.email.getText().toString().trim();
            val password:String =binding.password.getText().toString().trim();
            val cpassword:String =binding.cpassword.getText().toString().trim();


            if (fullname.isEmpty()) {
                Toast.makeText(baseContext, "Enter the full name", Toast.LENGTH_SHORT).show()
            } else if (type.isEmpty()) {
                Toast.makeText(baseContext, "Enter the type", Toast.LENGTH_SHORT).show()

            } else if (status.isEmpty()) {
                Toast.makeText(baseContext, "Enter the status", Toast.LENGTH_SHORT).show()

            } else if (fulladdress.isEmpty()) {
                Toast.makeText(baseContext, "Enter the full address", Toast.LENGTH_SHORT).show()

            } else if (contactNumber.isEmpty()) {
                Toast.makeText(baseContext, "Enter the contact Number", Toast.LENGTH_SHORT).show()

            } else if (panNumber.isEmpty()) {
                Toast.makeText(baseContext, "Enter the Pan Number", Toast.LENGTH_SHORT).show()

            } else if (gstNumber.isEmpty()) {
                Toast.makeText(baseContext, "Enter the gst Number", Toast.LENGTH_SHORT).show()

            } else if (designation.isEmpty()) {
                Toast.makeText(baseContext, "Enter the designation", Toast.LENGTH_SHORT).show()

            } else if (email.isEmpty()) {
                Toast.makeText(baseContext, "Enter the Email", Toast.LENGTH_SHORT).show()

            } else if (!Patterns.EMAIL_ADDRESS.matcher(binding.email.text.toString()).matches()) {
                Toast.makeText(baseContext, "Please Enter Valid Email id !", Toast.LENGTH_SHORT)
                    .show()
            } else if (password.isEmpty()) {
                Toast.makeText(baseContext, "Enter the Password", Toast.LENGTH_SHORT).show()

            } else if (cpassword.isEmpty()) {
                Toast.makeText(baseContext, "Enter the confirm Password", Toast.LENGTH_SHORT).show()

            } else if (!password.equals(cpassword)) {
                Toast.makeText(this, "Not MATCH", Toast.LENGTH_SHORT).show();
            }  else {
                val intent = Intent(baseContext, LoginActivity::class.java)
                startActivity(intent)
            }
        }
    }
}