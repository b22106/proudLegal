package com.proudlegal.Fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebViewClient
import com.proudlegal.R
import com.proudlegal.databinding.FragmentClintsBinding

class ClintsFragment : Fragment() {
    lateinit var binding: FragmentClintsBinding


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding= FragmentClintsBinding.inflate(layoutInflater, container, false)

        val data = arguments?.getString("key")
        data?.let { binding.webClints.loadUrl(it) }
        binding.webClints.settings.javaScriptEnabled = true
        binding.webClints.webViewClient = WebViewClient()

        return binding.root
    }
}