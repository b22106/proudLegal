package com.proudlegal.Fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebViewClient
import com.proudlegal.R
import com.proudlegal.databinding.FragmentInvoiceBinding


class InvoiceFragment : Fragment() {
lateinit var binding: FragmentInvoiceBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding= FragmentInvoiceBinding.inflate(layoutInflater, container, false)

        val data = arguments?.getString("key")
        data?.let { binding.webInvoice.loadUrl(it) }
        binding.webInvoice.settings.javaScriptEnabled = true
        binding.webInvoice.webViewClient = WebViewClient()
        return binding.root
    }

}