package com.proudlegal.Activity

import android.R.attr.key
import android.R.attr.value
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.proudlegal.Fragment.AchiveFragment
import com.proudlegal.Fragment.CasesFragment
import com.proudlegal.Fragment.ClintsFragment
import com.proudlegal.Fragment.HomeFragment
import com.proudlegal.Fragment.InvoiceFragment
import com.proudlegal.Fragment.NotificationFragment
import com.proudlegal.Fragment.ProfileFragment
import com.proudlegal.Fragment.SettingFragment
import com.proudlegal.R
import com.proudlegal.databinding.ActivityHomeBinding


class HomeActivity : AppCompatActivity() {
    lateinit var binding: ActivityHomeBinding
    lateinit var mDrawerLayout: DrawerLayout
    lateinit var mToggle: ActionBarDrawerToggle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.setting.setOnClickListener {
            val fragment=SettingFragment()
            supportFragmentManager.beginTransaction().replace(R.id.main_contenter ,fragment).commit()
        }
        binding.imgNotification.setOnClickListener {
            val fragment=NotificationFragment()
            supportFragmentManager.beginTransaction().replace(R.id.main_contenter ,fragment).commit()
        }
        binding.imgAchive.setOnClickListener {
            val fragment=AchiveFragment()
            supportFragmentManager.beginTransaction().replace(R.id.main_contenter ,fragment).commit()
        }

        mDrawerLayout = findViewById(R.id.drawer)
        mToggle = ActionBarDrawerToggle(this, mDrawerLayout, R.string.open, R.string.close)
        mDrawerLayout.addDrawerListener(mToggle)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        mToggle.syncState()


        binding.NavView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.profile -> {
                    val fragment=ProfileFragment()
                    supportFragmentManager.beginTransaction().replace(R.id.main_contenter,fragment).commit()

                    mDrawerLayout.close()
                    true
                }

                R.id.task_management -> {
//                    val uri = "https://www.proudtechnologies.com/privacy-policy.html"
//                    val intent = Intent(this, WebViewActivity::class.java)
//                    intent.putExtra("url", uri)
//                    startActivity(intent)
                    mDrawerLayout.close()
                    true
                }
                R.id.account_management -> {
//                    val uri = "https://www.proudtechnologies.com/privacy-policy.html"
//                    val intent = Intent(this, WebViewActivity::class.java)
//                    intent.putExtra("url", uri)
//                    startActivity(intent)
                    mDrawerLayout.close()
                    true
                }

                else -> {
                    false
                }
            }
        }
        supportFragmentManager.beginTransaction().replace(R.id.main_contenter, HomeFragment())
            .commit()
        supportActionBar?.hide()

        binding.bottomNavigation.setOnItemSelectedListener {
//            val fragment: Fragment
            when (it.itemId) {
                R.id.home -> {
                    val uri = "https://www.proudtechnologies.com/portfolio.html"
                    val fragment = HomeFragment()
                    val bundle = Bundle()
                    bundle.putString("key", uri)
                    fragment.arguments = bundle
                    supportFragmentManager.beginTransaction().replace(R.id.main_contenter, fragment).commit()
                    true
                }

                R.id.cases -> {
                    val uri = "https://www.proudtechnologies.com/portfolio.html"
                    val fragment = CasesFragment()
                    val bundle = Bundle()
                    bundle.putString("key", uri)
                    fragment.arguments = bundle


                    supportFragmentManager.beginTransaction().replace(R.id.main_contenter, fragment)
                        .commit()
                    true
                }

                R.id.Clints -> {
                    val uri = "https://www.proudtechnologies.com/portfolio.html"
                    val fragment = ClintsFragment()
                    val bundle = Bundle()
                    bundle.putString("key", uri)
                    fragment.arguments = bundle
                    supportFragmentManager.beginTransaction().replace(R.id.main_contenter, fragment)
                        .commit()
                    true
                }

                R.id.invoice -> {
                    val uri = "https://www.proudtechnologies.com/portfolio.html"
                    val fragment = InvoiceFragment()
                    val bundle = Bundle()
                    bundle.putString("key", uri)
                    fragment.arguments = bundle
                    supportFragmentManager.beginTransaction().replace(R.id.main_contenter, fragment)
                        .commit()

                    true
                }

                R.id.more -> {
                    mDrawerLayout.open()
                    true
                }

                else -> false
            }
        }
    }

}