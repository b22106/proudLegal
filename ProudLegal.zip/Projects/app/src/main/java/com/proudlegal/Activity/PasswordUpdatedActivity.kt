package com.proudlegal.Activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import com.proudlegal.databinding.ActivityPasswordUpdatedBinding

class PasswordUpdatedActivity : AppCompatActivity() {
    lateinit var binding: ActivityPasswordUpdatedBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityPasswordUpdatedBinding.inflate(layoutInflater)
        setContentView(binding.root)
        Handler().postDelayed({
            val i = Intent(this, LoginActivity::class.java)
            startActivity(i)
            finish()
        },2000)

    }
}