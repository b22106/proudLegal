package com.proudlegal.Activity

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.proudlegal.databinding.ActivityLoginBinding


class LoginActivity : AppCompatActivity() {
    lateinit var binding: ActivityLoginBinding
    private val PHONE_NUMBER = "+91-9779466813"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val id: String = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
        binding.deviceId.text = "Device ID: $id"


        binding.signupTxt.setOnClickListener {
            val intent = Intent(this, SignUpActivity::class.java)
            startActivity(intent)
        }
        binding.loginBtn.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            startActivity(intent)
            Toast.makeText(baseContext, "Login", Toast.LENGTH_SHORT).show()
        }
        binding.forgetPassTxt.setOnClickListener {
            val intent = Intent(this, ForgetActivity::class.java)
            startActivity(intent)
        }
        binding.givecall.setOnClickListener {
            val dialIntent = Intent(Intent.ACTION_DIAL)
            dialIntent.data = Uri.parse("tel:$PHONE_NUMBER")
            startActivity(dialIntent)
        }
    }
}