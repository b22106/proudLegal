package com.proudlegal.Fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebViewClient
import androidx.fragment.app.Fragment
import com.proudlegal.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {
lateinit var binding: FragmentHomeBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding=FragmentHomeBinding.inflate(layoutInflater, container, false)

        val data = arguments?.getString("key")
        data?.let { binding.webHome.loadUrl(it) }
        binding.webHome.settings.javaScriptEnabled = true
        binding.webHome.webViewClient = WebViewClient()
        return binding.root
    }


}