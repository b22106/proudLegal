package com.proudlegal.Fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebViewClient
import com.proudlegal.R
import com.proudlegal.databinding.FragmentCaseskBinding


class CasesFragment : Fragment() {
    lateinit var binding: FragmentCaseskBinding


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding= FragmentCaseskBinding.inflate(layoutInflater, container, false)

        val data = arguments?.getString("key")
        data?.let { binding.webCases.loadUrl(it) }
        binding.webCases.settings.javaScriptEnabled = true
        binding.webCases.webViewClient = WebViewClient() 

        return binding.root
    }
}