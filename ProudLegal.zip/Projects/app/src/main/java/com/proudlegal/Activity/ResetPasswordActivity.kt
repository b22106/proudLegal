package com.proudlegal.Activity

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.proudlegal.databinding.ActivityResetPasswordBinding

class ResetPasswordActivity : AppCompatActivity() {
    lateinit var binding: ActivityResetPasswordBinding
    private val PHONE_NUMBER = "+91-9779466813"



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResetPasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.updateBtn.setOnClickListener {
            val password: String = binding.passwordReset.text.toString().trim()
            val cpassword: String = binding.cpasswordReset.text.toString().trim()
            if(password.isEmpty()){
                Toast.makeText(this,"Enter the password",Toast.LENGTH_SHORT).show()
            }else if (cpassword.isEmpty()){
                Toast.makeText(this,"Enter the confirm password",Toast.LENGTH_SHORT).show()
            }else if (!password.equals(cpassword)){
                Toast.makeText(this,"Not match password",Toast.LENGTH_SHORT).show()

            }else{
                val intent = Intent(this, PasswordUpdatedActivity::class.java)
                startActivity(intent)
            }


        }
        binding.backOtp.setOnClickListener {
            finish()
        }
        binding.givecall.setOnClickListener {
            val dialIntent = Intent(Intent.ACTION_DIAL)
            dialIntent.data = Uri.parse("tel:$PHONE_NUMBER")
            startActivity(dialIntent)
        }
    }
}