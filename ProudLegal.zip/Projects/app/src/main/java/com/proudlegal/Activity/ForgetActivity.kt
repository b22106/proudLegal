package com.proudlegal.Activity

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.proudlegal.databinding.ActivityForgetBinding

class ForgetActivity : AppCompatActivity() {
    lateinit var binding: ActivityForgetBinding
    private val PHONE_NUMBER = "+91-9779466813"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityForgetBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.backLogin.setOnClickListener {
            finish()
        }
        binding.nextBtn.setOnClickListener {
            val intent=Intent(this, OtpActivity::class.java)
            startActivity(intent)
        }
        binding.givecall.setOnClickListener {
            val dialIntent = Intent(Intent.ACTION_DIAL)
            dialIntent.data = Uri.parse("tel:$PHONE_NUMBER")
            startActivity(dialIntent)
        }
    }
}